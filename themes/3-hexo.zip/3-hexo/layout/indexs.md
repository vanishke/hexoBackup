---
title: 前言
---
# 博客的初衷

通过博客，我们可以记录自己的生活和成长的轨迹。它不像 Twitter 那样碎片化，也不像 Facebook 那样关系化，它是私人的空间。

## 关于
vanishke的个人技术博客。

到目前为止已经写了<code class="article_number"></code>篇文章， 共<code class="site_word_count"></code>字。
本站访问人数：<code class="site_uv"></code>人次 ， 访问量：<code class="site_pv"></code>次

## 博客平台
这个博客通过 [Hexo](https://hexo.io/) 生成，部署在 [GitHub Pages](https://pages.github.com/)主题 [3-hexo]( https://vanishke.github.io/hexo) 已经在github上开源


主要功能：
- 搜索支持文章标题、标签(#标签)、作者(@作者)
- pad/手机等移动端适配
- 页面全局快捷键 <a href='https://hexo-sigma-eight.vercel.app/2020/11/18/3-hexo-shortcuts/'>3-hexo快捷键说明</a>