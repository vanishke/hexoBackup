'use strict';

describe('Helpers', () => {
  require('./font');
  require('./next-url');
});
