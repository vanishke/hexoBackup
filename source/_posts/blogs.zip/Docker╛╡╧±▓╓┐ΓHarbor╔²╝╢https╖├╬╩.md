---
title: Docker镜像仓库Harbor升级https访问
categories:
	- Harbor
tags: 
	- Harbor
	- Docker
	
date: 2025-04-03 14:52:34
updated: 2025-04-03 14:52:34
---
<!-- toc -->
# <span id="inline-blue">环境</span>
Docker: 27.3.1
docker compose: v2.29.7
Harbor: v2.12.1

# <span id="inline-blue">背景</span>
公司内网环境下部署harbor一直使用的http,导致docker配置harbor镜像仓库需要添加如下配置：
```yml
{
    "insecure-registries": ["http://my.harbor.com"
}
```
拉取镜像文件经常出现超时，所以决定将Harbor仓库通信协议升级为https，并配置好局域网内的域名和IP之间映射，这样既保证了docker拉取镜像文件时的安全保证，同时也为harbor服务后续升级到公网打下基础。

# <span id="inline-blue">实现</span>

## <span id="inline-blue">更新配置</span>

更改harbor.yml配置文件,内容如下：

```yml
# Configuration file of Harbor

# The IP address or hostname to access admin UI and registry service.
# DO NOT use localhost or 127.0.0.1, because Harbor needs to be accessed by external clients.
hostname: my.harbor.com

# http related config
#http:
  # port for http, default is 80. If https enabled, this port will redirect to https port
#  port: 80

# https related config
https:
  # https port for harbor, default is 443
  port: 443
  # The path of cert and key files for nginx
  certificate: /usr/local/harbor/https/server.pem
  private_key: /usr/local/harbor/https/server.key
  # enable strong ssl ciphers (default: false)
  # strong_ssl_ciphers: false
```

harbor主目录执行以下命令更新harbor内部服务配置

```shell
#假设harbor在/usr/local/harbor
cd /usr/local/harbor
./prepare
```

my.harbor.com是局域网自定义域名，certificate、private_key对应自签名证书和私钥
因为是局域网自定义的域名，并且使用的是自签名证书，所以需要在服务端和客户端配置域名和IP映射，让通信的双方都知道域名对应的IP地址。

Linux:
修改/etc/hosts文件，增加以下内容：

```shell
10.9.216.14  my.harbor.com
```

windows：
修改C:\Windows\System32\drivers\etc\hosts文件(使用管理员权限)，增加如下内容：

```shell
10.9.216.14  my.harbor.com
```

更改之后使用以下命令刷新dns

```shell
ipconfig /flushdns
```

## <span id="inline-blue">生成https证书</span>

```shell

#my.harbor.com/10.9.216.14
#指定/home路径下生成certificate.jks证书，秘钥为coshipOk698
keytool -genkey -alias photoframe  -keyalg RSA -keysize 2048 -validity 3650 -ext SAN=dns:my.harbor.com,ip:10.9.216.14 -keystore /usr/local/harbor/https/certificate.jks -storepass coshipOk698 -dname "CN=my.harbor.com, OU=my.harbor.com, O=my.harbor.com, L=wuhan, ST=wuhan, C=cn"


#certificate.jks是键值对形式的证书，推荐转换为标准格式pkcs12
keytool -importkeystore -srckeystore certificate.jks -destkeystore certificate.jks -deststoretype pkcs12

#将certificate.jks证书导出，certificate.jks已经是pkcs12格式
keytool -export -trustcacerts -alias photoframe -file /usr/local/harbor/https/cas.crt -keystore /usr/local/harbor/https/certificate.jks -storepass coshipOk698

#将cas.crt格式转换为server.pem，方便nginx使用
openssl x509 -inform der -in cas.crt -out server.pem

#提取密钥
openssl pkcs12 -nocerts -nodes -in certificate.jks -out server.key
```

最后使用的只有server.pem、server.key两个文件，将这两个文件上传到harbor.yml配置文件指定的路径。


## <span id="inline-blue">验证</span>

执行以下命令重启harbor服务

```shell
	systemctl stop harbor.service
	systemctl start harbor.service
```

![Harbor升级https](/images/Harbor/20250403/Harbor_20250403_001.png)
