---
title: Hexo文章添加阴影效果
tags: 
	- Hexo
categories: 
	- Hexo

date: 2022-05-18 09:32:12
updated: 2022-05-18 09:32:12
---

## <span id="inline-blue">文章添加阴影效果</span>
打开themes/next/source/css/_custom/custom.styl文件添加:
```css
.post {
  margin-top: 60px;
  margin-bottom: 60px;
  padding: 25px;
  -webkit-box-shadow: 0 0 5px rgba(202, 203, 203, .5);
  -moz-box-shadow: 0 0 5px rgba(202, 203, 204, .5);
 }
```










