---
title: Hexo修改加载特效
tags: 
	- Hexo
categories: 
	- Hexo

date: 2022-05-18 09:32:12
updated: 2022-05-18 09:32:12
---

## <span id="inline-blue">修改加载特效</span>
搜索pace，找到如下代码：
```shell
# 页面顶部加载条
# Progress bar in the top during page loading.
pace: true
# Themes list:
#pace-theme-big-counter
#pace-theme-bounce
#pace-theme-barber-shop
#pace-theme-center-atom
#pace-theme-center-circle
#pace-theme-center-radar
#pace-theme-center-simple
#pace-theme-corner-indicator
#pace-theme-fill-left
#pace-theme-flash
#pace-theme-loading-bar
#pace-theme-mac-osx
#pace-theme-minimal
# For example
# pace_theme: pace-theme-center-simple
pace_theme: pace-theme-minimal  #默认设置，可以修改为上述任何一个
```








