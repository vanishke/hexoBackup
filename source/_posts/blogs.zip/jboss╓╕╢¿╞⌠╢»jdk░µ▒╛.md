---
title: Jboss 指定启动JDK版本
categories: Jboss
date: 2020-11-17 10:00:12
tags: Jboss
---


## linux环境

```bash
文件名称：run.conf  文件路径：/usr/local/jboss-5.1.0.GA/bin
文件头部添加以下内容：
JAVA_HOME="/usr/java/jdk1.6.0"
```



