---
title: Jetty 指定启动JDK版本
categories: 
	- Jetty
tags: 
	- Jetty

date: 2020-11-17 10:11:12
updated: 2020-11-17 10:11:12
---

## <span id="inline-blue">linux环境</span>

```bash
文件名称：setenv.sh 文件路径：/usr/local/
文件头部添加以下内容：
export JAVA_HOME=/usr/java/jdk1.6.0_21
export JRE_HOME=/usr/java/jdk1.6.0_21/jre
```



