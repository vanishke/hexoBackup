---
title: Hexo归档页优化
tags: 
	- Hexo
categories: 
	- Hexo

date: 2021-01-12 10:11:20
updated: 2021-01-12 10:11:20
---

## <span id="inline-blue">hexo归档页优化<span>

修改/themes/next/layout/_macro/post-collapse.swig后的代码如下：










