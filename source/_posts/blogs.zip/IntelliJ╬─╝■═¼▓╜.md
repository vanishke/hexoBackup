---
title: IntelliJ项目文件同步 
tags: 
	- IntelliJ
categories: 
	- IntelliJ

date: 2021-01-15 16:55:20	
updated: 2021-01-15 16:55:20
---


## <span id="inline-blue">文件同步</span>
选中项目需要同步的文件，File工具栏选择synchronize同步操作
![同步](/images/intelliJ/intelliJ_2021_02_18_001.png)