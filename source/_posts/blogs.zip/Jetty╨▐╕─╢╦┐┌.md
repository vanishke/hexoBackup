---
title: Jetty修改端口号
categories: 
	- Jetty
tags: 
	- Linux
	- Jetty

date: 2021-06-10 14:40:12
updated: 2021-06-10 14:40:12
---

## <span id="inline-blue">linux环境</span>

文件名称：start.ini 
文件路径：jetty安装目录下（/usr/local/jetty_home）
#文件内搜索对应标识jetty.port

![jetty变更端口号](/images/jetty/jetty_2021_06_10_001.png)


