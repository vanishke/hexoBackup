---
title: IntelliJ插件Lombok离线安装
tags: 
	- IntelliJ
	- Lombok
categories: 
	- IntelliJ

date: 2021-05-06 17:08:23	
updated: 2021-05-06 17:08:23
---

# <span id="inline-blue">官网下载地址</span> 
http://plugins.jetbrains.com/plugin/6317-lombok-plugin
![下载地址](/images/intelliJ/inteliJ_2021_03_25_001.png)
![版本选择](/images/intelliJ/inteliJ_2021_03_25_002.png)
自行根据Intelij版本下载对应的安装包，intelij版本和lombok保持一致即可。


提供Intelij2018.2.1版本对应的离线安装包
https://pan.baidu.com/s/1kBg_t-75859dIOnRLYe_jg 提取码：0hn4

# <span id="inline-blue">离线安装</span> 
![lombok离线安装](/images/intelliJ/inteliJ_2021_03_25_003.png)
加载对应版本的zip格式的安装包，重启intelij生效


